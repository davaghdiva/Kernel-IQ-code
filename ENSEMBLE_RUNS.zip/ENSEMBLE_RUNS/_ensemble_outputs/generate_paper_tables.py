"""
Name    : generate_paper_tables.py
Author  : William Smyth
Contact : drwss.academy@gmail.com
Date    : 26/03/2026
Desc    : central parameter configuration for the Kernel-IQ (WIQ) project.
Generate the manuscript LaTeX for FRL Table 1 and Table 2 directly from the
ensemble summary CSV files.

Expected inputs in the chosen directory:
    - ensemble_metric_summary_long.csv
    - ensemble_rank_summary.csv
    - ensemble_per_metric_rank_summary_long.csv

Outputs:
    - table1_main_metrics.tex
    - table2_rank_summary.tex

Usage:
    python generate_frl_tables.py --input-dir . --output-dir .

This script does not recompute portfolio statistics from raw returns. It simply
extracts, pivots, formats, and writes the paper tables from the already
generated ensemble summary CSV files.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd


# Paper ordering and labels
METHOD_ORDER = ["WIQ", "GS_opt", "LS2", "LS3", "LS1"]
METHOD_LABELS = {
    "WIQ": "Kernel--IQ",
    "GS_opt": r"$\mathrm{GS}_{opt}$",
    "LS2": "LS2",
    "LS3": "LS3",
    "LS1": "LS1",
}

TABLE1_METRICS = [
    "Annualized Return (%)",
    "Annualized STD (%)",
    "Sharpe Ratio",
    "Sortino Ratio",
    "Calmar Ratio",
    "Cumulative Return (%)",
    "Maximum Drawdown (%)",
    "Monthly 95% VaR (%)",
    "Turnover",
]

TABLE1_DECIMALS = {
    "Annualized Return (%)": 2,
    "Annualized STD (%)": 2,
    "Sharpe Ratio": 3,
    "Sortino Ratio": 3,
    "Calmar Ratio": 3,
    "Cumulative Return (%)": 2,
    "Maximum Drawdown (%)": 2,
    "Monthly 95% VaR (%)": 2,
    "Turnover": 2,
}

TABLE2_ROWS = [
    ("Aggregate rank", "aggregate"),
    (r"$\Pr(\text{best aggregate rank})$", "pbest"),
    ("Sharpe rank", "Sharpe Ratio"),
    ("Sortino rank", "Sortino Ratio"),
    ("Annualized STD rank", "Annualized STD (%)"),
    ("Maximum Drawdown rank", "Maximum Drawdown (%)"),
    ("Monthly 95\\% VaR rank", "Monthly 95% VaR (%)"),
    ("Turnover rank", "Turnover"),
    ("Calmar rank", "Calmar Ratio"),
    ("Annualized Return rank", "Annualized Return (%)"),
    ("Cumulative Return rank", "Cumulative Return (%)"),
]

TABLE2_DECIMALS = {
    "Aggregate rank": 2,
    r"$\Pr(\text{best aggregate rank})$": None,  # formatted as percent / --
    "Sharpe rank": 2,
    "Sortino rank": 2,
    "Annualized STD rank": 2,
    "Maximum Drawdown rank": 2,
    "Monthly 95\\% VaR rank": 2,
    "Turnover rank": 2,
    "Calmar rank": 2,
    "Annualized Return rank": 2,
    "Cumulative Return rank": 2,
}


def format_number(value: float, decimals: int) -> str:
    return f"{value:.{decimals}f}"


def format_probability(value: float | None) -> str:
    if pd.isna(value):
        return "--"
    if abs(value - round(value)) < 1e-12:
        return f"{int(round(value))}\\%"
    return f"{value:.2f}\\%"


def validate_columns(df: pd.DataFrame, required: set[str], filename: str) -> None:
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"{filename} is missing required columns: {sorted(missing)}")


def build_table1(metric_df: pd.DataFrame) -> str:
    validate_columns(
        metric_df,
        {"Method", "Metric", "mean"},
        "ensemble_metric_summary_long.csv",
    )

    # In this CSV, `Method` holds metric names and `Metric` holds estimator names.
    pivot = metric_df.pivot(index="Method", columns="Metric", values="mean")

    missing_metrics = [m for m in TABLE1_METRICS if m not in pivot.index]
    missing_methods = [m for m in METHOD_ORDER if m not in pivot.columns]
    if missing_metrics or missing_methods:
        raise ValueError(
            f"Table 1 inputs missing metrics={missing_metrics} or methods={missing_methods}"
        )

    header = "Metric & " + " & ".join(METHOD_LABELS[m] for m in METHOD_ORDER) + r" \\"
    lines = [
        r"\begin{table}[!htbp]",
        r"\centering",
        r"\caption{Mean out-of-sample portfolio metrics across 50 optimizer seeds}",
        r"\label{tab:main_metrics}",
        r"\small",
        r"\begin{tabular}{lccccc}",
        r"\toprule",
        header,
        r"\midrule",
    ]

    for metric in TABLE1_METRICS:
        row_values = [
            format_number(float(pivot.loc[metric, method]), TABLE1_DECIMALS[metric])
            for method in METHOD_ORDER
        ]
        lines.append(f"{metric}   & " + " & ".join(row_values) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    return "\n".join(lines) + "\n"


def build_table2(rank_df: pd.DataFrame, per_metric_rank_df: pd.DataFrame) -> str:
    validate_columns(
        rank_df,
        {"Method", "mean", "P_best_%"},
        "ensemble_rank_summary.csv",
    )
    validate_columns(
        per_metric_rank_df,
        {"Method", "MetricRank", "mean"},
        "ensemble_per_metric_rank_summary_long.csv",
    )

    rank_indexed = rank_df.set_index("Method")
    per_metric_pivot = per_metric_rank_df.pivot(index="Method", columns="MetricRank", values="mean")

    missing_methods = [m for m in METHOD_ORDER if m not in rank_indexed.index]
    if missing_methods:
        raise ValueError(f"Table 2 inputs missing aggregate-rank methods={missing_methods}")

    header = "Rank summary & " + " & ".join(METHOD_LABELS[m] for m in METHOD_ORDER) + r" \\"
    lines = [
        r"\begin{table}[!htbp]",
        r"\centering",
        r"\caption{Aggregate and per-metric rank summaries across 50 optimizer seeds}",
        r"\label{tab:rank_summary}",
        r"\small",
        r"\begin{tabular}{lccccc}",
        r"\toprule",
        header,
        r"\midrule",
    ]

    for row_label, source_key in TABLE2_ROWS:
        if source_key == "aggregate":
            values = [
                format_number(float(rank_indexed.loc[method, "mean"]), TABLE2_DECIMALS[row_label])
                for method in METHOD_ORDER
            ]
        elif source_key == "pbest":
            values = [format_probability(rank_indexed.loc[method, "P_best_%"]) for method in METHOD_ORDER]
        else:
            if source_key not in per_metric_pivot.index:
                raise ValueError(f"Per-metric rank row missing: {source_key}")
            values = [
                format_number(float(per_metric_pivot.loc[source_key, method]), TABLE2_DECIMALS[row_label])
                for method in METHOD_ORDER
            ]
        lines.append(f"{row_label}   & " + " & ".join(values) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate FRL LaTeX tables from ensemble summary CSV files.")
    parser.add_argument("--input-dir", default=".", help="Directory containing the ensemble summary CSV files.")
    parser.add_argument("--output-dir", default=".", help="Directory to which LaTeX table files will be written.")
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    metric_path = input_dir / "ensemble_metric_summary_long.csv"
    rank_path = input_dir / "ensemble_rank_summary.csv"
    per_metric_rank_path = input_dir / "ensemble_per_metric_rank_summary_long.csv"

    for path in [metric_path, rank_path, per_metric_rank_path]:
        if not path.exists():
            raise FileNotFoundError(f"Required input file not found: {path}")

    metric_df = pd.read_csv(metric_path)
    rank_df = pd.read_csv(rank_path)
    per_metric_rank_df = pd.read_csv(per_metric_rank_path)

    table1_tex = build_table1(metric_df)
    table2_tex = build_table2(rank_df, per_metric_rank_df)

    (output_dir / "table1_main_metrics.tex").write_text(table1_tex, encoding="utf-8")
    (output_dir / "table2_rank_summary.tex").write_text(table2_tex, encoding="utf-8")

    print(f"Wrote {output_dir / 'table1_main_metrics.tex'}")
    print(f"Wrote {output_dir / 'table2_rank_summary.tex'}")


if __name__ == "__main__":
    main()
